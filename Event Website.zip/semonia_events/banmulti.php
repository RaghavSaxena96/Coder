<?php include("config.php");

    $random_id = mt_rand() ;
 $category = $_POST['category'] ;
 
    for($i=0; $i<count($_FILES['pic_eve']['name']); $i++) {
	$path = "banner/";
	$name = $_FILES['pic_eve']['name'][$i];
	$size = $_FILES['pic_eve']['size'][$i];  
    list($txt, $ext) = explode(".", $name);
	$file= time().substr(str_replace(" ", "_", $txt), 0);
	$info = pathinfo($file);
	$filename = $file.".".$ext;
	move_uploaded_file($_FILES['pic_eve']['tmp_name'][$i], $path.$filename); 
	$file_name_all.=$filename."*";
	}
	
	$filepath = rtrim( $file_name_all, '*' );

    $save=mysql_query("INSERT INTO `semonia`.`banner` (`random_id`, `banpic`, `banno`) VALUES ('".$random_id."', '".$filepath."', '".$category."'  );");
	
	header( 'location:backend.php?sts3=successfully uploaded !' );
	
	exit();

 ?>
 