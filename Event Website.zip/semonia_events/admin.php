<?php 
    include("config.php");
	
	session_start();
	
	if( $_SESSION["var_admin"] == 'OK'){
	
	header("location:backend.php");
	
	}
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Semonia events</title>

<link href="https://fonts.googleapis.com/css?family=Lobster+Two" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Great+Vibes" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Abel" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Didact+Gothic" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Yanone+Kaffeesatz" rel="stylesheet">

 <link href="css/style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="css/font-awesome.css">

        <link href='css/slider_a.css' rel='stylesheet' type='text/css'>
        <link href='css/slider_b.css' rel='stylesheet' type='text/css'>
        
  <link rel="stylesheet"  type="text/css"  href="css/r_menu.css">
  <link rel="stylesheet"  type="text/css"  href="css/style.css">
  <link rel="stylesheet"  type="text/css"  href="css/font-awesome.css">
  <link rel="stylesheet" type="text/css" href="css/tabs.css" />
  <link rel="stylesheet" type="text/css" href="css/tabstyles.css" />

  <script src="js/modernizr.custom.js"></script>
  
  <link rel="stylesheet" type="text/css" href="css/lightcase.css">
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="js/lightcase.js"></script>
<script type="text/javascript" src="js/jquery.events.touch.js"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$('a[data-rel^=lightcase]').lightcase();
		swipe: true
	});
	
</script>
	
  

</head>

<body>
<div id="main_container">

<div id="menu_container">

<div id="logo"><a href="index.php"><img src="images/logo.png" /></a></div>

<div id="menu">
<nav class="responsive-menu">
	<a href="#" class="toggle-menu" data-toggle-class="active" data-toggle-target=".main-menu, this"><svg height="32" viewBox="0 0 32 32" width="32" xmlns="http://www.w3.org/2000/svg"><path d="M4 10h24c1.104 0 2-.896 2-2s-.896-2-2-2H4c-1.104 0-2 .896-2 2s.896 2 2 2zm24 4H4c-1.104 0-2 .896-2 2s.896 2 2 2h24c1.104 0 2-.896 2-2s-.896-2-2-2zm0 8H4c-1.104 0-2 .896-2 2s.896 2 2 2h24c1.104 0 2-.896 2-2s-.896-2-2-2z" fill="#fff"/></svg><span>Menu</span></a>
	
    <ul class="main-menu">
        <li><a href="index.php"><span>Home</span></a> 
            
        </li>
        <li><a href="about.php"><span>About us</span></a>
           
        </li>
        <li><a href="gallery.php"><span>Gallery</span></a></li>
        <li><a href="contact.php"><span>Contact us</span></a></li>
        <li><a href="service.php"><span>Services</span></a></li>
        
        <li><a href="admin.php"><span>Login</span></a></li>
    </ul>
  </nav>


</div>
<div class="do_clear"></div>
</div>















<!--<div id="contact_container">
<div id="Gallery_container">
<div id="Gallery_Text">CONTACT US</div>

</div>

<div id="contact">
<div id="contact_left">
<table width="100%" border="0" cellpadding="20px">
  <tr>
    <td width="20%" >Email</td>
    <td width="80%" >veracebyveronica@gmail.com</td>
  </tr>
 <tr>
    <td width="20%" >Mobile</td>
    <td width="80%" >(+91)-8126640811,(+91)-9412374811</td>
  </tr>
  
 <tr>
    <td width="20%" >Address</td>
    <td width="80%" >29 Amar Vihar Dayal Bagh Agra</td>
  </tr>  
  
  <tr>
    <td width="20%" >Landmark</td>
    <td width="80%" >Near S.T. Conrad Inter College</td>
  </tr>
 <tr>
    <td width="20%" >Fax</td>
    <td width="80%" >(0562)-282345</td>
  </tr>
  
 <tr>
    <td width="20%" >Time</td>
    <td width="80%" >10.00 am to 5.00pm</td>
  </tr>  
</table>
</div>
<div id="contact_right">
<table width="100%" border="0">
  <tr>
    <td ><iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d7096.513939655513!2d78.004739!3d27.2110808!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3974775129928ba1%3A0x743c2d6b9e6937fa!2sDIGIKOLORZ!5e0!3m2!1sen!2sin!4v1496301216648" width="100%" height="400" frameborder="0" style="border:0" allowfullscreen></iframe></td>
    
  </tr>

</table>
</div>
</div>
<div class="do_clear"></div>
</div>
-->

<div id="enquiry_container">

<div id="enquiry">
<div id="need_head">Admin Login</br >
</div>
</div>
<div id="service_content">
Please fill correct username and passsword for admin login
<div style="color:#99CC00;"><?php 
if($_GET['sts']!=''){
echo $_GET['sts'];
}
?>
</div>



<div id="details">

<div class="section group">

<div class="col span_2_of_4">
<div class="highlights">

<form action="adminchk.php" method="post" enctype="multipart/form-data">

<input class="field5"  name="username" type="text" placeholder="USERNAME" required />
<input class="field5"  name="password" type="password" placeholder="PASSWORD" required />

<div class="do_clear"></div>
<input class="submit_button" type="submit" value="Login" />
</form>
</div>
</div>


<div class="col span_2_of_4">
<div class="highlights">

<div class="do_clear"></div>
<div id="admin_logo"><img src="images/logo_b.png" /></div>

</div>
</div>





</div>



</div>
<div class="do_clear"></div>
</div>
<div class="do_clear"></div>
</div>

<div id="bottom_container">
<div id="bottom">

<div id="footer_content">
<div class="need_box">
<div class="bottom_logo"><img src="images/logo.png" /></div>
<div class="bottom_lower">
We are team based on Brookylin. Our expertise on Interior Design. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.
</div>
</div>
</div>

<div id="footer_content">
<div class="need_box">
<div class="bottom_heading">Services</div>
<div class="bottom_lower">
<div id="line">Co-operate events</div>
<div id="line">Wedding Planers</div>
<div id="line">Musical Groups</div>
<div id="line">Dance Group</div>
<div id="line">Events Organisers</div>
</div>
</div>
</div>

<div id="footer_content">
<div class="need_box">
<div class="bottom_heading">Contact Us</div>
<div class="bottom_lower">
<div id="line">wish you good luck</div>
<div id="line">wish you good luck</div>
<div id="line">wish you good luck</div>
<div id="line">wish you good luck</div>
<div id="line">wish you good luck</div>
<div id="line">wish you good luck</div>
</div>
</div>
</div>
<div class="do_clear"></div>

</div>
<div class="do_clear"></div>
</div>


<div id="footer_container">
<div id="footer">
<div class="footer_content">
<a href="about_us.html">HOME</a>/
<a href="hosting_city.html">ABOUT US</a>/
<a href="#">ENQURY</a>/
 <a href="designers.html">CONTACT US</a>/
 <a href="#"> TERMS & CONDITIONS</a>/
 <a href="sponsors.html">PRIVACY POLICY</a>/ 
 <a href="#">PAYMENTS</a>/
<a href="social.html"> SUPPORT </a>/
  <a href="contact.html"> SHIPPING</a></div>
<div id="design_by">
<div id="design_text"><a href="http://www.digikolorz.com/" target="_blank">DESIGN BY</a></div> 
<div id="design_img"><img src="images/digikolorz_logo.png" /></div> 
</div>

<div class="do_clear"></div>

</div>
</div>





</div>


<script src="js/r_menu.js"></script>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
        <script src="js/jquery.touch.js"></script>
        <script src="js/slider.js"></script>
        <script>
            // init slider plugin
            var slider = $('.slider'),
                saSlider = slider.saSlider().data('_saSlider');

            // lazy load all photos that should be lazy loaded..
            slider.find('img[data-src]').each(function(){
                this.src = this.getAttribute('data-src');
            });

           
        </script>
        
      
</body>
</html>
