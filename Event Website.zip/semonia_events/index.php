<?php 
include("config.php");

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Semonia events</title>

<link href="https://fonts.googleapis.com/css?family=Lobster+Two" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Great+Vibes" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Abel" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Didact+Gothic" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Yanone+Kaffeesatz" rel="stylesheet">

 <link href="css/style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="css/font-awesome.css">

        <link href='css/slider_a.css' rel='stylesheet' type='text/css'>
        <link href='css/slider_b.css' rel='stylesheet' type='text/css'>
        
  <link rel="stylesheet"  type="text/css"  href="css/r_menu.css">
  <link rel="stylesheet"  type="text/css"  href="css/style.css">
  <link rel="stylesheet"  type="text/css"  href="css/font-awesome.css">
  <link rel="stylesheet" type="text/css" href="css/tabs.css" />
  <link rel="stylesheet" type="text/css" href="css/tabstyles.css" />

  <script src="js/modernizr.custom.js"></script>
  
  <link rel="stylesheet" type="text/css" href="css/lightcase.css">
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="js/lightcase.js"></script>
<script type="text/javascript" src="js/jquery.events.touch.js"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$('a[data-rel^=lightcase]').lightcase();
		swipe: true
	});
	
</script>
	
  

</head>

<body>
<div id="main_container">

<div id="menu_container">

<div id="logo"><a href="index.php"><img src="images/logo.png" /></a></div>

<div id="menu">
<nav class="responsive-menu">
	<a href="#" class="toggle-menu" data-toggle-class="active" data-toggle-target=".main-menu, this"><svg height="32" viewBox="0 0 32 32" width="32" xmlns="http://www.w3.org/2000/svg"><path d="M4 10h24c1.104 0 2-.896 2-2s-.896-2-2-2H4c-1.104 0-2 .896-2 2s.896 2 2 2zm24 4H4c-1.104 0-2 .896-2 2s.896 2 2 2h24c1.104 0 2-.896 2-2s-.896-2-2-2zm0 8H4c-1.104 0-2 .896-2 2s.896 2 2 2h24c1.104 0 2-.896 2-2s-.896-2-2-2z" fill="#fff"/></svg><span>Menu</span></a>
	
    <ul class="main-menu">
        <li><a href="index.php"><span>Home</span></a> 
            
        </li>
        <li><a href="about.php"><span>About us</span></a>
            
        </li>
        <li><a href="gallery.php"><span>Gallery</span></a></li>
        <li><a href="contact.php"><span>Contact us</span></a></li>
        <li><a href="service.php"><span>Services</span></a></li>
        <li><a href="admin.php"><span>Login</span></a></li>
    </ul>
  </nav>


</div>
<div class="do_clear"></div>
</div>

<div id="banner_container">

<div class="slider"> <a class="arrow next"></a> <a class="arrow prev"></a>
      <ul>
      <?php $a = mysql_query("SELECT * FROM `banner` ORDER BY id ASC"); ?>
      <?php while( $b = mysql_fetch_array($a)){ ?>
      <?php $path= explode("*",$b['banpic']);
			$i=count($path);
			$file_path = 'banner/';
			for($x=0;$x<$i;$x++){
			$src=$file_path.$path[$x]; ?>
            
        <li class="active"> <img src="<?=$src?>"/>
            <div class="content">
              <h1>photo by </h1>
              <div class="by"> <span>Georgi Karastoyanov</span> <a href="#" target="blank">Semoniaevents.com</a> </div>
            </div>
        </li>
        
        <?php } }  ?> 
      </ul>
  </div>
  <div class="do_clear"></div>
</div>

<div id="service_container">
<div id="service_header">Retina ready professional and <span>clean</span> design</div>
<div id="service_content">
On the other hand,we denounce with righteous indignation and dislike men who are beguiled by the <span>charms</span> of pleasure of the moment,
so blindly by desire,that they force the path.
</div>




<div id="services">
<div class="section group">

<div class="col span_1_of_4">
<div class="highlights">
<div class="icons"><i class="fa fa-heart" aria-hidden="true"></i></div>
<div class="do_clear"></div>
<div class="icons_heading">Wedding Events</div>
<div class="icons2">On the other hand we denounce with rightous indignation and dislike men who are so asure of moment</div>
</div>
</div>

<div class="col span_1_of_4">
<div class="highlights">
<div class="icons"><i class="fa fa-heart-o" aria-hidden="true"></i></div>
<div class="do_clear"></div>
<div class="icons_heading">Marriage Proposals</div>
<div class="icons2">On the other hand we denounce with rightous indignation and dislike men who are so asure of moment</div>
</div>
</div>


<div class="col span_1_of_4">
<div class="highlights">
<div class="icons"><i class="fa fa-music" aria-hidden="true"></i></div>
<div class="do_clear"></div>
<div class="icons_heading">Musical Events</div>
<div class="icons2">On the other hand we denounce with rightous indignation and dislike men who are so asure of moment</div>
</div>
</div>


<div class="col span_1_of_4">
<div class="highlights">
<div class="icons"><i class="fa fa-birthday-cake" aria-hidden="true"></i></div>
<div class="do_clear"></div>
<div class="icons_heading">Birthday Parties</div>
<div class="icons2">On the other hand we denounce with rightous indignation and dislike men who are so asure of moment</div>
</div>
</div>


<div class="do_clear"></div>

</div>


</div>

</div>

<div id="service_container2">

<div id="service_header2">Our Services</div>

<div id="service_content1">
On the other hand,we denounce with righteous indignation and dislike men who are beguiled by the <span>charms</span> of pleasure of the moment,</br>
so blindly by desire,that they force the path.
<div class="do_clear"></div>
</div>


<div id="show_service">

<div class="section group">

<div class="col span_1_of_6">

<div class="service_box">

<div class="icons3"><i class="fa fa-music" aria-hidden="true"></i></div>
<div class="icons3_heading">Music Night</div>
</div>
</div>

<div class="col span_1_of_6">

<div class="service_box">

<div class="icons3"><i class="fa fa-heart" aria-hidden="true"></i></div>
<div class="icons3_heading">Wedding Cerimonies</div>
</div>
</div>

<div class="col span_1_of_6">

<div class="service_box">

<div class="icons3"><i class="fa fa-glass" aria-hidden="true"></i></div>
<div class="icons3_heading">Late Night Party</div>
</div>
</div>

<div class="col span_1_of_6">

<div class="service_box">

<div class="icons3"><i class="fa fa-music" aria-hidden="true"></i></div>
<div class="icons3_heading">Ballon Dercorations</div>
</div>
</div>

<div class="col span_1_of_6">

<div class="service_box">

<div class="icons3"><i class="fa fa-music" aria-hidden="true"></i></div>
<div class="icons3_heading">Dance Group</div>
</div>
</div>


<div class="col span_1_of_6">

<div class="service_box">

<div class="icons3"><i class="fa fa-glass" aria-hidden="true"></i></div>
<div class="icons3_heading">Kitty Parties</div>
</div>
</div>

</div>
<div class="do_clear"></div>
</div>

</div>


<div id="need">

<div id="need_head">Why do you choose <span>Semonia Event</span></div>

<div id="service_content">
On the other hand,we denounce with righteous indignation and dislike men who are beguiled by the <span>charms</span> of pleasure of the moment,</br>
so blindly by desire,that they force the path.
<div class="do_clear"></div>
</div>


<div id="need_cont">

<div class="section group">

<div class="col span_1_of_3">

<div class="need_box">
<div class="need_inbox"><i class="fa fa-music" aria-hidden="true"></i></div>
<div class="need_heading">BE</div>
<div class="need_lower">On the other hand we denounce with rightous indignation and dislike men who are so asure of moment</div>
</div>


</div>

<div class="col span_1_of_3">

<div class="need_box">
<div class="need_inbox"><i class="fa fa-music" aria-hidden="true"></i></div>
<div class="need_heading">100% REPONSIVE DESIGN</div>
<div class="need_lower">On the other hand we denounce with rightous indignation and dislike men who are so asure of moment</div>
</div>


</div>


<div class="col span_1_of_3">

<div class="need_box">
<div class="need_inbox"><i class="fa fa-music" aria-hidden="true"></i></div>
<div class="need_heading">100% REPONSIVE DESIGN</div>
<div class="need_lower">On the other hand we denounce with rightous indignation and dislike men who are so asure of moment</div>
</div>
</div>
</div>
<div class="do_clear"></div>
</div>

</div>


<div id="need1">
<div id="need_head1"><span>Semonia's</span> creative team</div>

<div id="service_content1">
On the other hand,we denounce with righteous indignation and dislike men who are beguiled by the <span>charms</span> of pleasure of the moment,</br>
so blindly by desire,that they forcee the path.
<div class="do_clear"></div>
</div>

<div id="team_cont">
<div id="gallery">
              <ul>
<?php 
 $row = mysql_query("SELECT * FROM `pics` ORDER BY id Asc"); 
while($result = mysql_fetch_array ($row) ) {
 ?>

<?php

$path = explode('*',$result['pic']);
$filepath = 'pics/' ;
//$src = $path[0];

?>

              <?php for ($x = 0; $x < count($path); $x++)
            { $src = $path[$x]; 
			echo '<li><a href="'.$filepath.$src.'" data-rel="lightcase:myCollection:slideshow"><img src="'.$filepath.$src.'" alt=""/></a></li>'; } 
          } ?>
        
               
             </ul><div class="do_clear"></div>
             </div>
	
<div class="do_clear"></div>
</div>
</div>


<div id="enquiry_container">

<div id="enquiry">
<div id="need_head">Fill the Enquiry form</br >
<div style="color:#99CC00;"><?php 
if($_GET['sts']!=''){
echo $_GET['sts'];
}
?></div>
</div>
<div id="service_content">
Please fill the form correctly to send thw enquiry,check the details filled before pressing the submit button
</div>



<div id="details">
<form action="send_enquiry.php" method="post" enctype="multipart/form-data">
<input class="field1"  name="name" type="text" placeholder="NAME" required />
<input class="field1"  name="phone" type="text" placeholder="PHONE NUMBER" required />
<input  class="field1"  name="email" type="text" placeholder="EMAIL" required>
<input  class="field1"   name="city" type="text" placeholder="CITY" required/>

<input class="field3"  name="event" type="text" placeholder="EVENT-TYPE" required />
<input class="field3"  name="address" type="text" placeholder="ADDRESS" required />


<textarea class="field_area"  name="message" cols="" rows=""></textarea>
<div class="do_clear"></div>
<input class="submit_button" type="submit" />
</form>
</div>
</div>
<div class="do_clear"></div>
</div>

<div id="bottom_container">
<div id="bottom">

<div id="footer_content">
<div class="need_box">
<div class="bottom_logo"><img src="images/logo.png" /></div>
<div class="bottom_lower">
We are team based on Brookylin. Our expertise on Interior Design. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.
</div>
</div>
</div>

<div id="footer_content">
<div class="need_box">
<div class="bottom_heading">Services</div>
<div class="bottom_lower">
<div id="line">Co-operate events</div>
<div id="line">Wedding Planers</div>
<div id="line">Musical Groups</div>
<div id="line">Dance Group</div>
<div id="line">Events Organisers</div>
</div>
</div>
</div>

<div id="footer_content">
<div class="need_box">
<div class="bottom_heading">Contact Us</div>
<div class="bottom_lower">
<div id="line">wish you good luck</div>
<div id="line">wish you good luck</div>
<div id="line">wish you good luck</div>
<div id="line">wish you good luck</div>
<div id="line">wish you good luck</div>
<div id="line">wish you good luck</div>
</div>
</div>
</div>
<div class="do_clear"></div>

</div>
<div class="do_clear"></div>
</div>


<div id="footer_container">
<div id="footer">
<div class="footer_content">
<a href="about_us.html">HOME</a>/
<a href="hosting_city.html">ABOUT US</a>/
<a href="#">ENQURY</a>/
 <a href="designers.html">CONTACT US</a>/
 <a href="#"> TERMS & CONDITIONS</a>/
 <a href="sponsors.html">PRIVACY POLICY</a>/ 
 <a href="#">PAYMENTS</a>/
<a href="social.html"> SUPPORT </a>/
  <a href="contact.html"> SHIPPING</a></div>
<div id="design_by">
<div id="design_text"><a href="http://www.digikolorz.com/" target="_blank">DESIGN BY</a></div> 
<div id="design_img"><img src="images/digikolorz_logo.png" /></div> 
</div>

<div class="do_clear"></div>

</div>
</div>





</div>


<script src="js/r_menu.js"></script>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
        <script src="js/jquery.touch.js"></script>
        <script src="js/slider.js"></script>
        <script>
            // init slider plugin
            var slider = $('.slider'),
                saSlider = slider.saSlider().data('_saSlider');

            // lazy load all photos that should be lazy loaded..
            slider.find('img[data-src]').each(function(){
                this.src = this.getAttribute('data-src');
            });

           
        </script>
        
      
</body>
</html>
