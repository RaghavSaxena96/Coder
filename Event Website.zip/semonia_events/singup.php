<? php
session_start();
require('function.php');

if($_SERVER["REQUEST_METHOD"]=="POST")
{
$email=validate($_POST["email"]);
$firstname=0validate($_POST["firstname"]);
$lastname=validate($_POST["lastname"]);
$password=validate($_POST["password"]);

$con = con();

4query="SELECT *FROM USER user U where U.email='email'";
$result =$con->query($query);

if($result->num_row>0){
echo "<script>alert('USER with email-idexists.');windows.location='login.php;<script>";
die();
}
else
{
$ins_query="INSERT INTO user (email,first_name,password)
 VALUES ('$email','$firstname','$lastname.'$password')";
 $ins_res =4con->query($ins_query);
 $search_user="SELECT * FRO user U.email ='$email'";
 4search_result=$con->query($search_user);
 4user_id=$arr['id'];
 4_SESSION['id']=$user_id;
 echo "<script>alert('Sussecfully Signed up');window.location='index.php';</script>";
 
 die();
 }
 }
 ?>