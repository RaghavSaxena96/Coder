<?php  
    include("config.php");
	
	session_start();
	
	if( $_SESSION["var_admin"] != 'OK') {
	
	header("location:admin.php");
	
	
	}
	error_reporting(0);
	?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Semonia events</title>

<link href="https://fonts.googleapis.com/css?family=Lobster+Two" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Great+Vibes" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Abel" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Didact+Gothic" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Yanone+Kaffeesatz" rel="stylesheet">

 <link href="css/style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="css/font-awesome.css">

   <link rel="stylesheet" type="text/css" href="css/normalize.css" />
  <link rel="stylesheet"  type="text/css"  href="css/font-awesome.css">
  <link rel="stylesheet" type="text/css" href="css/tabs.css" />
  <link rel="stylesheet" type="text/css" href="css/tabstyles.css" />

  <link rel="stylesheet" href="css/easy-responsive-tabs.css">


	
  

</head>

<body>
<div id="main_container">

<div id="menu_container">

<div id="logo"><a href="index.php"><img src="images/logo.png" /></a></div>

<div id="menu">

<div id="logout">
<a href="admin_logout.php">LOGOUT</a>
</div>

</div>
<div class="do_clear"></div>
</div>


<div id="enquiry_container">

<div id="enquiry">
<div id="need_head">Welcome to Admin Panel</br >
</div>
</div>
<div id="service_content">
<div id="horizontalTab">
<ul class="resp-tabs-list">
<li>ENQUIRY</li>
<li>GALLERY</li>
<li>GALLERY UPDATE</li>
<li>BANNER UPDATE</li>
</ul>
<div class="resp-tabs-container">

<div>
<div id="details">





 <table width="100%" border="1">
  <tr>
    <td>name</td>
    <td>phone</td>
    <td>email</td>
    <td>city</td>
    <td>event</td>
    <td>address</td>
    <td>message</td>
  </tr>
  
  
   <?php 
 $a = mysql_query("SELECT * FROM `enquiry` ORDER BY id Asc"); 
  
 
 while($b = mysql_fetch_array ($a))
    { 
	
echo ' <tr><td>'.$b[name].'</td>
      <td>'.$b[phone].'</td>
	  <td>'.$b[email].'</td>
	  <td>'.$b[city].'</td>
	  <td>'.$b[event].'</td>
	  <td>'.$b[address].'</td>
	  <td>'.$b[message].'</td>
	    </tr>';
			
	} 
   
    ?>
   
  

  
</table>


</div>
<div class="do_clear"></div>
</div>

<div>
Select category and Pics to upload
<div style="color:#99CC00;">
  <?php 
if($_GET['sts']!=''){
echo $_GET['sts'];
}
?>
</div>



<div id="details">



            <div class="do_clear"></div>



<form action="multifile.php" method="post" enctype="multipart/form-data">
<input class="field3"  name="category" type="text" placeholder="Category" required />
<label>
<input class="file_field" type="file" name="pic_eve[]" multiple="multiple" id="fileField" />
</label>

<div class="do_clear"></div>
<input class="submit_button" type="submit" />
</form>
</div>
</div>


<div>
Select category and Pics to upload
<div style="color:#99CC00;"><?php 
if($_GET['sts1']!=''){
echo $_GET['sts1'];
}
?>
</div>



<div id="details">



            <div class="do_clear"></div>



<form action="update_multifile.php" method="post" enctype="multipart/form-data">
<input class="field3"  name="category" type="text" placeholder="Category" required />
<label>
<input class="file_field" type="file" name="pic_eve[]" multiple="multiple" id="fileField" />
</label>

<div class="do_clear"></div>
<input class="submit_button" type="submit" />
</form>
</div>
</div>

<div>

Select Banner number and Pic to update
<div style="color:#99CC00;"><?php 
if($_GET['sts2']!=''){
echo $_GET['sts2'];
}
?>
</div>



<div id="details">



            <div class="do_clear"></div>



<form action="update_banner.php" method="post" enctype="multipart/form-data">

<select class="field3" name="category">
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
</select>

<label>
<input class="file_field" type="file" name="pic_eve[]" id="fileField" />
</label>

<div class="do_clear"></div>
<input class="submit_button" type="submit" />
</form>
</div>

</div>





</div>

</div>
</div>

</div>

</div>



<div id="bottom_container">
<div id="bottom">

<div id="footer_content">
<div class="need_box">
<div class="bottom_logo"><img src="images/logo.png" /></div>
<div class="bottom_lower">
We are team based on Brookylin. Our expertise on Interior Design. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.
</div>
</div>
</div>

<div id="footer_content">
<div class="need_box">
<div class="bottom_heading">Services</div>
<div class="bottom_lower">
<div id="line">Co-operate events</div>
<div id="line">Wedding Planers</div>
<div id="line">Musical Groups</div>
<div id="line">Dance Group</div>
<div id="line">Events Organisers</div>
</div>
</div>
</div>

<div id="footer_content">
<div class="need_box">
<div class="bottom_heading">Contact Us</div>
<div class="bottom_lower">
<div id="line">wish you good luck</div>
<div id="line">wish you good luck</div>
<div id="line">wish you good luck</div>
<div id="line">wish you good luck</div>
<div id="line">wish you good luck</div>
<div id="line">wish you good luck</div>
</div>
</div>
</div>
<div class="do_clear"></div>

</div>
<div class="do_clear"></div>
</div>


<div id="footer_container">
<div id="footer">
<div class="footer_content">
<a href="about_us.html">HOME</a>/
<a href="hosting_city.html">ABOUT US</a>/
<a href="#">ENQURY</a>/
 <a href="designers.html">CONTACT US</a>/
 <a href="#"> TERMS & CONDITIONS</a>/
 <a href="sponsors.html">PRIVACY POLICY</a>/ 
 <a href="#">PAYMENTS</a>/
<a href="social.html"> SUPPORT </a>/
  <a href="contact.html"> SHIPPING</a></div>
<div id="design_by">
<div id="design_text"><a href="http://www.digikolorz.com/" target="_blank">DESIGN BY</a></div> 
<div id="design_img"><img src="images/digikolorz_logo.png" /></div> 
</div>

<div class="do_clear"></div>

</div>
</div>





</div>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
<script src="js/easy-responsive-tabs.js"></script>
<script>
$(document).ready(function () {
$('#horizontalTab').easyResponsiveTabs({
type: 'default', //Types: default, vertical, accordion           
width: 'auto', //auto or any width like 600px
fit: true,   // 100% fit in a container
closed: 'accordion', // Start closed if in accordion view
activate: function(event) { // Callback function if tab is switched
var $tab = $(this);
var $info = $('#tabInfo');
var $name = $('span', $info);
$name.text($tab.text());
$info.show();
}
});
$('#verticalTab').easyResponsiveTabs({
type: 'vertical',
width: 'auto',
fit: true
});
});
</script>

           
</body>
</html>
