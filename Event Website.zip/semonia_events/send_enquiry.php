<?php 

include("config.php");

$random_id= mt_rand();

$name=$_POST["name"];
$phone=$_POST["phone"];
$email=$_POST["email"];
$city=$_POST["city"];
$event=$_POST["event"];
$address=$_POST["address"];
$message=$_POST["message"];


$save=mysql_query("INSERT INTO `enquiry` (`random_id`, `name`, `phone`, `email`, `city`, `event`, `address`, `message`)
 VALUES ( 
 '".$random_id."',
 '".$name."', 
 '".$phone."', 
 '".$email."',
 '".$city."',
 '".$event."',
 '".$address."',
 '".$message."'
  )");


//redirect to the 'thank you' page
header("location:index.php?sts=Message Successfully Posted#enquiry");
exit;	

?>