<?Php

session_start();

unset($_SESSION["var_admin"]);

//------------------------//

header("location: admin.php");

exit();

?>