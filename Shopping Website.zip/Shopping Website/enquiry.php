<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1.0" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Verace By Veronica</title>
<link href="https://fonts.googleapis.com/css?family=Great+Vibes" rel="stylesheet">
<link href='http://fonts.googleapis.com/css?family=Oswald:400,300,700' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=PT+Sans:400,700' rel='stylesheet' type='text/css'>

<link rel="stylesheet" href="css/font-awesome.css">
<link rel="stylesheet" type="text/css" media="all" href="css/stellarnav.css">
<link href="css/style.css" rel="stylesheet" type="text/css" />


<link rel="stylesheet" href="css/owl.carousel.css" >
<link rel="stylesheet" href="css/owl.theme.css">
<link rel="stylesheet" href="css/form.css" >
    
<link href="http://www.jqueryscript.net/css/jquerysctipttop.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="css/main.css" />
<link rel="stylesheet" href="http://netdna.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
   
   
 
<script src="js/jquery-1.9.1.min.js"></script> 
  <script type="text/javascript" src="main.js"></script> 
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script src="js/owl.carousel.js"></script>



</head>

<body>

<div id="main_container">

<div id="top_container">

<div id="info_container">

<div id="left">
<div id="wishlist">
<div id="information"><a href="#"><i class="fa fa-user"></i>&nbsp; My Account</a></div>
<div id="information"><a href="#"><i class="fa fa-heart" aria-hidden="true"></i>&nbsp; My Wishlist</a></div>
</div>
</div>

<div id="right">
<div id="wishlist">
<div id="register"><a href="#"><i class="fa fa-shopping-cart" aria-hidden="true"></i>&nbsp; My Cart</a></div>
<div id="register"><a href="#"><i class="fa fa-user"></i>&nbsp; Log In</a></div>
</div>
</div>
<div class="do_clear"></div>
</div>

<div id="logo_container">
<div id="logo"><img src="images/logo.png" /></div>
<div id="logo_text">Verace by Veronica</div>
</div>

</div>



<div id="menu">
<div id="main_menu">

<div id="menu_container">

<div id="main-nav" class="stellarnav">
		<ul>
			<li><a href="index.html">HOME</a></li>
              <li><a href="about_us.html">ABOUT US</a></li>
            
		     <li><a href="enquiry.php">ENQUIRY</a> </li>
           
          
               
             <li class="drop-left">
               <a href="contact_us.html">CONTACT US</a> </li>
		</ul>
	</div>

</div>

</div>

<div id="highlight_menu">
<div class="higmenu_box"><a href="festive.html">FESTIVES</a></div>
<div class="higmenu_box"><a href="wedding.html">WEDDING</a></div>
<div class="higmenu_box"><a href="formal.html">FORMAL</a></div>
<div class="higmenu_box"><a href="party.html">PARTY</a></div>
<div class="higmenu_box"><a href="ethinic.html">ETHINIC</a></div>
<div class="do_clear"></div>
</div>

<div class="do_clear"></div>
</div>

<div id="container">
    
  <div class="slider_container">
    
      <ul>
        <li class="current_slide"><img src="images/1.jpg" /></li>
        <li><img src="images/2.jpg" /></li>
        <li><img src="images/5.jpg" /></li>
        <li><img src="images/4.jpg" /></li>
      </ul>
      <span class="prev_slide"><i class="fa fa-angle-left" aria-hidden="true"></i></span>
      <span class="next_slide"><i class="fa fa-angle-right" aria-hidden="true"></i></span>
      <div class="buttons"></div>  
      <span class="play_pause"><i class="fa fa-pause"></i></span>
      
  </div>
    
  </div>

<div id="line"></div>

<div id="content">




<div id="Gallery_container">
<div id="Gallery_Text">ENQUIRY FORM
<?php 
if($_GET['sts']!=''){
echo $_GET['sts'];
}
?>
</div>

</div>
<div id="matter">

<form action="send_query.php" method="post" enctype="multipart/form-data">
<input  class="field_1" type="text" name="fname" placeholder="First Name" required>
<input  class="field_1"  type="text" name="lname" placeholder="Last Name" required/>
<input  class="field_1"  type="text" name="number" placeholder="Phone Number" required/>
<input  class="field_1"  type="text" name="age" placeholder="Age" required />
<input  class="field_2"  type="text" name="gender" placeholder="Gender" required/>
<input  class="field_2"  type="text" name="email" placeholder="Email" required/>
<input  class="field_3"  type="text" name="address" placeholder="Address" required/>
<textarea class="field_area"  name="query" cols="" rows=""></textarea>
<input class="field_4" type="submit" />
</form>

<div class="do_clear"></div>
</div>
</div>


<div id="footer_container">
<div id="footer">
<div class="footer_content">
<a href="about_us.html">HOME</a>/
<a href="hosting_city.html">ABOUT US</a>/
<a href="#">ENQURY</a>/
 <a href="designers.html">CONTACT US</a>/
 <a href="#"> TERMS & CONDITIONS</a>/
 <a href="sponsors.html">PRIVACY POLICY</a>/ 
 <a href="#">PAYMENTS</a>/
<a href="social.html"> SUPPORT </a>/
  <a href="contact.html"> SHIPPING</a></div>
<div id="design_by">
<div id="design_text"><a href="http://www.digikolorz.com/" target="_blank">DESIGN BY</a></div> 
<div id="design_img"><img src="images/digikolorz_logo.png" /></div> 
</div>

<div class="do_clear"></div>

</div>
</div>

</div>
</body>


<script>
    $(document).ready(function() {
      $("#owl-demo1").owlCarousel({
        autoPlay: 10000,
        items : 1,
        itemsDesktop : [1199,3],
        itemsDesktopSmall : [979,3]
      });
	  
	  $("#owl-demo2").owlCarousel({
        autoPlay:10000,
        items :1,
        itemsDesktop : [1199,3],
        itemsDesktopSmall : [979,3]
      });
	  
	   $("#owl-demo3").owlCarousel({
        autoPlay: 10000,
        items : 1,
        itemsDesktop : [1199,3],
        itemsDesktopSmall : [979,3]
      });
	  
	   $("#owl-demo4").owlCarousel({
        autoPlay: 10000,
        items : 4,
        itemsDesktop : [1199,3],
        itemsDesktopSmall : [979,3]
      });

    });
    </script>

	<script type="text/javascript" src="js/stellarnav.min.js"></script>
	<script type="text/javascript">
		jQuery(document).ready(function($) {
			jQuery('.stellarnav').stellarNav({
				theme: 'dark'
			});
		});
	</script>

</html>
