function categoryb(event) {

	var category_b_name = category_b_from.category_b.value;
	var xmlhttp = new XMLHttpRequest();
	xmlhttp.onreadystatechange = function(){
	if(xmlhttp.readyState==4&&xmlhttp.status==200){
	document.getElementById('subcategory_b').innerHTML = xmlhttp.responseText;}}
	xmlhttp.open('GET', 'category_b.php?category_b='+category_b_name, true);
	xmlhttp.send();

}

function categoryc(event) {

	var category_c_name = category_c_from.category_c.value;
	var xmlhttp = new XMLHttpRequest();
	xmlhttp.onreadystatechange = function(){
	if(xmlhttp.readyState==4&&xmlhttp.status==200){
	document.getElementById('subcategory_c').innerHTML = xmlhttp.responseText;}}
	xmlhttp.open('GET', 'category_c.php?category_c='+category_c_name, true);
	xmlhttp.send();

}

function subcategory(event) {

	var category_c_name = category_c_from.category_c.value;
	var subcategory_c_name = category_c_from.subcategory_c.value;
	var xmlhttp = new XMLHttpRequest();
	xmlhttp.onreadystatechange = function(){
	if(xmlhttp.readyState==4&&xmlhttp.status==200){
	document.getElementById('undersubcategory_d').innerHTML = xmlhttp.responseText;}}
	xmlhttp.open('GET', 'subcategory.php?category='+category_c_name+'&subcategory='+subcategory_c_name, true);
	xmlhttp.send();
}

function categoryf(event) {

	var category_f_name = category_f_from.category_f.value;
	var xmlhttp = new XMLHttpRequest();
	xmlhttp.onreadystatechange = function(){
	if(xmlhttp.readyState==4&&xmlhttp.status==200){
	document.getElementById('deletesubmenu').innerHTML = xmlhttp.responseText;}}
	xmlhttp.open('GET', 'deletesubmenu.php?deletesubmenu='+category_f_name, true);
	xmlhttp.send();
	
}

function categoryg(event) {

	var category_g_name = category_g_from.category_g.value;
	var xmlhttp = new XMLHttpRequest();
	xmlhttp.onreadystatechange = function(){
	if(xmlhttp.readyState==4&&xmlhttp.status==200){
	document.getElementById('undersubmenu_g').innerHTML = xmlhttp.responseText;}}
	xmlhttp.open('GET', 'category_g.php?category_g='+category_g_name, true);
	xmlhttp.send();
	
}

function undersubmenug(event) {

	var submenu_g_name = category_g_from.category_g.value;
	var undersubmenu_g_name = category_g_from.undersubmenu_g.value;
	var xmlhttp = new XMLHttpRequest();
	xmlhttp.onreadystatechange = function(){
	if(xmlhttp.readyState==4&&xmlhttp.status==200){
	document.getElementById('deleteundersubmenu').innerHTML = xmlhttp.responseText;}}
	xmlhttp.open('GET', 'deleteundersubmenu.php?deleteundersubmenu='+undersubmenu_g_name+'&category='+submenu_g_name, true);
	xmlhttp.send();
	
}
     
function categoryh(event) {

	var category_h_name = products_history.category_h.value;
	var xmlhttp = new XMLHttpRequest();
	xmlhttp.onreadystatechange = function(){
	if(xmlhttp.readyState==4&&xmlhttp.status==200){
	document.getElementById('subcategory_h').innerHTML = xmlhttp.responseText;}}
	xmlhttp.open('GET', 'category_h.php?category_h='+category_h_name, true);
	xmlhttp.send();
	
}

function subcategoryh(event) {


	var category_h_name = products_history.category_h.value;
	var subcategory_h_name = products_history.subcategory_h.value;
	var xmlhttp = new XMLHttpRequest();
	xmlhttp.onreadystatechange = function(){
	if(xmlhttp.readyState==4&&xmlhttp.status==200){
	document.getElementById('undersubcategory_h').innerHTML = xmlhttp.responseText;}}
	xmlhttp.open('GET', 'subcategory_h.php?category_h='+category_h_name+'&subcategory_h='+subcategory_h_name, true);
	xmlhttp.send();
	
}

function undersubcategoryh(event) {

	var type = products_history.type_h.value;
	var category = products_history.category_h.value;
	var subcategory = products_history.subcategory_h.value;
	var undersubcategory = products_history.undersubcategory_h.value;
	
	var xmlhttp = new XMLHttpRequest();
	xmlhttp.onreadystatechange = function(){
	if(xmlhttp.readyState==4&&xmlhttp.status==200){
	
	document.getElementById('deleteproducts').innerHTML = xmlhttp.responseText;}}
	
	xmlhttp.open('GET', 'deleteproducts.php?type='+type+'&category='+category+'&subcategory='+subcategory+'&undersubcategory='+undersubcategory, true);
	
	xmlhttp.send();
	
}

function categoryj(event) {

	var category_j_name = bannera.category_j.value;
	var xmlhttp = new XMLHttpRequest();
	xmlhttp.onreadystatechange = function(){
	if(xmlhttp.readyState==4&&xmlhttp.status==200){
	document.getElementById('subcategory_j').innerHTML = xmlhttp.responseText;}}
	xmlhttp.open('GET', 'category_j.php?category_j='+category_j_name, true);
	xmlhttp.send();
	
}

function categoryk(event) {

	var category_k_name = bannerb.category_k.value;
	var xmlhttp = new XMLHttpRequest();
	xmlhttp.onreadystatechange = function(){
	if(xmlhttp.readyState==4&&xmlhttp.status==200){
	document.getElementById('subcategory_k').innerHTML = xmlhttp.responseText;}}
	xmlhttp.open('GET', 'category_k.php?category_k='+category_k_name, true);
	xmlhttp.send();
	
}

function categoryl(event) {

	var category_l_name = bannerc.category_l.value;
	var xmlhttp = new XMLHttpRequest();
	xmlhttp.onreadystatechange = function(){
	if(xmlhttp.readyState==4&&xmlhttp.status==200){
	document.getElementById('subcategory_l').innerHTML = xmlhttp.responseText;}}
	xmlhttp.open('GET', 'category_l.php?category_l='+category_l_name, true);
	xmlhttp.send();
	
}

function categorym(event) {

	var category_m_name = bannerd.category_m.value;
	var xmlhttp = new XMLHttpRequest();
	xmlhttp.onreadystatechange = function(){
	if(xmlhttp.readyState==4&&xmlhttp.status==200){
	document.getElementById('subcategory_m').innerHTML = xmlhttp.responseText;}}
	xmlhttp.open('GET', 'category_m.php?category_m='+category_m_name, true);
	xmlhttp.send();
	
}

function categoryn(event) {

	var category_n_name = bannere.category_n.value;
	var xmlhttp = new XMLHttpRequest();
	xmlhttp.onreadystatechange = function(){
	if(xmlhttp.readyState==4&&xmlhttp.status==200){
	document.getElementById('subcategory_n').innerHTML = xmlhttp.responseText;}}
	xmlhttp.open('GET', 'category_n.php?category_n='+category_n_name, true);
	xmlhttp.send();
	
}

function categoryo(event) {

	var category_o_name = bannerf.category_o.value;
	var xmlhttp = new XMLHttpRequest();
	xmlhttp.onreadystatechange = function(){
	if(xmlhttp.readyState==4&&xmlhttp.status==200){
	document.getElementById('subcategory_o').innerHTML = xmlhttp.responseText;}}
	xmlhttp.open('GET', 'category_o.php?category_o='+category_o_name, true);
	xmlhttp.send();
	
}

function categoryp(event) {

	var category_p_name = bannerg.category_p.value;
	var xmlhttp = new XMLHttpRequest();
	xmlhttp.onreadystatechange = function(){
	if(xmlhttp.readyState==4&&xmlhttp.status==200){
	document.getElementById('subcategory_p').innerHTML = xmlhttp.responseText;}}
	xmlhttp.open('GET', 'category_p.php?category_p='+category_p_name, true);
	xmlhttp.send();
	
}

function categoryq(event) {

	var category_q_name = bannerh.category_q.value;
	var xmlhttp = new XMLHttpRequest();
	xmlhttp.onreadystatechange = function(){
	if(xmlhttp.readyState==4&&xmlhttp.status==200){
	document.getElementById('subcategory_q').innerHTML = xmlhttp.responseText;}}
	xmlhttp.open('GET', 'category_q.php?category_q='+category_q_name, true);
	xmlhttp.send();
	
}

function categoryr(event) {

	var category_r_name = banneri.category_r.value;
	var xmlhttp = new XMLHttpRequest();
	xmlhttp.onreadystatechange = function(){
	if(xmlhttp.readyState==4&&xmlhttp.status==200){
	document.getElementById('subcategory_r').innerHTML = xmlhttp.responseText;}}
	xmlhttp.open('GET', 'category_r.php?category_r='+category_r_name, true);
	xmlhttp.send();
	
}


function categorys(event) {

	var category_s_name = bannerj.category_s.value;
	var xmlhttp = new XMLHttpRequest();
	xmlhttp.onreadystatechange = function(){
	if(xmlhttp.readyState==4&&xmlhttp.status==200){
	document.getElementById('subcategory_s').innerHTML = xmlhttp.responseText;}}
	xmlhttp.open('GET', 'category_s.php?category_s='+category_s_name, true);
	xmlhttp.send();
	
}


$(document).ready(function(){ $("#allsize").hide(); });

function allsize(event) {
    
	var currentSize = document.getElementById("psize").value ;
    $(document).ready(function(){ if(currentSize!='Size Disable'){$("#allsize").show();}else{$("#allsize").hide();} });
	
}

function showproduct(event) {
	
	var stylecode = showupdate.stylecode.value;
	var randomid = showupdate.randomid.value;
	
	var xmlhttp = new XMLHttpRequest();
	xmlhttp.onreadystatechange = function(){
	if(xmlhttp.readyState==4&&xmlhttp.status==200){
	document.getElementById('updateproducts').innerHTML = xmlhttp.responseText;}}
	xmlhttp.open('GET', 'showproduct.php?stylecode='+stylecode+'&randomid='+randomid, true);
	xmlhttp.send();
	
}

function showproduct(event) {
		
	randomid  = encodeURIComponent(document.getElementById('randomidupdate').value) ;
	stylecode = encodeURIComponent(document.getElementById('stylecodeupdate').value) ;
	
	$( '#updateproducts' ).load('showproduct.php?stylecode='+stylecode+'&randomid='+randomid);
	
}
