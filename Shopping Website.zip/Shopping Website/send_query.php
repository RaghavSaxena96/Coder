<?php 
$fname=$_POST["fnmae"];
$lname=$_POST["lnmae"];
$number=$_POST["number"];
$email=$_POST["email"];
$age=$_POST["age"];
$gender=$_POST["gender"];
$address=$_POST["address"];


$to = "raghavconradian@gmail.com" ;
$subject = "NEW QUERY FROM  WEBSITE";
$headers .= "Content-type:text/html;charset=UTF-8";

$query = '<table width="100%" border="1" cellspacing="0" cellpadding="10" style="border: 1px solid #DBDBDB; font-size:15px; border-collapse: collapse; font-family:Verdana, Arial, Helvetica, sans-serif;" >

 <tr><td><strong>FIRST NAME :</strong> '.$fname.'</td></tr>
  <tr><td><strong>LAST NAME :</strong> '.$lname.'</td></tr>
   <tr> <td><strong>PHONE :</strong> '.$number.'</td></tr>
    <tr><td><strong>EMAIL :</strong> '.$email.'</td></tr>
	<tr><td><strong>PINCODE :</strong> '.$gender.'</td></tr>
	<tr><td><strong>STATE :</strong> '.$age.'</td></tr>
<tr><td><strong>ADDRESS :</strong> '.$address.'</td></tr>
  
</table>';

@mail($to,$subject,$query,$headers);
//redirect to the 'thank you' page
header("location:enquiry.php?sts=Message Successfully Posted#enquiry");
exit;	

?>