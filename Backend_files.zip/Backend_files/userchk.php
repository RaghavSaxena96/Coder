<?php

	include("config.php");
	
    $a = mysql_query("SELECT * FROM login_table WHERE user LIKE '".$_POST["username"]."' ");  

    $b = mysql_fetch_array($a);
	
	if( $_POST["username"]==$b['user'] and $_POST["password"]==$b['pass'] ){
	
	session_start();

    $_SESSION["var_admin"] = "OK";
	
	header("location: backend.php");

 	}
	
	else{
	 
	header("location: admin.php?sts=Username or Password is wrong please try again");
	
	}

?>