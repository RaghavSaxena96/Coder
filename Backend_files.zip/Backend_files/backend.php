<?php
include("config.php");

session_start();
	
	if( $_SESSION["var_admin"] != 'OK') {
	
	header("location:admin.php");
	
	}



?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>login panel</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>

<body>

<div id="main_container">
<div id="logout"><a href="admin_logout.php">logout</a></div>
<div id="input">
Select category and Pics to upload
<div style="color:#99CC00;"><?php 
if($_GET['sts']!=''){
echo $_GET['sts'];
}
?>
</div>

<div id="upload">

<form action="multifile.php" method="post" enctype="multipart/form-data">
  <input class="box" name="category" type="text"  placeholder="Category" required/>
  <input class="box" name="pic_eve[]" type="file" multiple="multiple"  />
  <input name="submit" type="submit" />
</form>


</div>
<div class="do_clear"></div>
</div>

</div>


</body>
</html>

<?php  $row = mysql_query("SELECT * FROM `pics` WHERE `random_id` = ".$_GET['rid']); $result = mysql_fetch_array( $row );  ?>

<?php

$path = explode('*',$result['pics']);
$filepath = 'pics/' ;
//$src = $path[0];

?>

<?php for ($x = 0; $x < count($path); $x++) { $src = $path[$x]; echo '<img src="'.$filepath.$src.'" style="width:100px; height:100px;">' . '</br>' ; } ?>
 
