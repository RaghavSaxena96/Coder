<?php include("config.php");

    $random_id = mt_rand() ;
 $category = $_POST['category'] ;
 
    for($i=0; $i<count($_FILES['pic_eve']['name']); $i++) {
	$path = "pics/";
	$name = $_FILES['pic_eve']['name'][$i];
	$size = $_FILES['pic_eve']['size'][$i];  
    list($txt, $ext) = explode(".", $name);
	$file= time().substr(str_replace(" ", "_", $txt), 0);
	$info = pathinfo($file);
	$filename = $file.".".$ext;
	move_uploaded_file($_FILES['pic_eve']['tmp_name'][$i], $path.$filename); 
	$file_name_all.=$filename."*";
	}
	
	$filepath = rtrim( $file_name_all, '*' );

    $save=mysql_query("INSERT INTO `login`.`pics` (`random_id`, `pic`, `category`) VALUES ('".$random_id."', '".$filepath."', '".$category."'  );");
	
	header( 'location:index.php?rid='.$random_id.'&status=successfully uploaded !' );
	
	exit();

 ?>
 