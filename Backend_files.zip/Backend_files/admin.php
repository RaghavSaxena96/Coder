
<?php 
    include("config.php");
	
	session_start();
	
	if( $_SESSION["var_admin"] == 'OK'){
	
	header("location:backend.php");
	
	}
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>admin</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>

<body>
<div id="main_container">

<div id="top_head">
<div style="color:#FFFFFF;">
  <?php 
if($_GET['sts']!=''){
echo $_GET['sts'];
}
?>
  <div id="left"></div>
<div id="right">
<div id="login">
<form action="userchk.php" method="post"  enctype="multipart/form-data">
  <input  class="box"    name="username" type="text"  placeholder="USERNAME" required/>
  <input  class="box"    name="password" type="password" placeholder="PASSWORD" required />
  <input name="submit" type="submit"  value="Login"/>
</form>
</div>
</div>
<div class="do_clear"></div>
</div>
</div>


</body>
</html>
